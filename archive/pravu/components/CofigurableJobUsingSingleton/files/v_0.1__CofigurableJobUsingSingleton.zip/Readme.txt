
The Zip file contains the following files. 

1. MDIntegrationTalendSource.zip
2. Sample ETL job.doc
3. OracleSourceTableScript.txt
4. UKConfig.xml
5. MDIntegration_0.1.zip

Execution:
==========
For execution of job use the following steps.
1)extract the contents of MDIntegration_0.1.zip to a folder.
2)Place the UKConfig.xml file in d: drive in windows.
3)Modify the database credentials for oracle(source) and MSSql(target) databases
4)Execute the oracle source database script for creating table and inserting values
5)Execute the batch file inside the MDIntegration_0.1.zip file.

After execution check the log file that you have mentioned in the UKConfig.xml file.

The windows batch file can be modified for placing the UKConfig.xml at another folder.

Importing into TOS(Talend open Studio) and modifying
====================================================

Extract the contents of MDIntegrationTalendSource.zip file into a folder and import the TOS project file into TOS.
See the provided document about the job for getting more information.

Thanks,
Pravu Mishra.

