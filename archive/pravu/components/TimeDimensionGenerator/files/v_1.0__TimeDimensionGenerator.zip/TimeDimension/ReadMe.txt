1) Extrect the zip file contents(the talend project) into a folder
2) Import the project into TOS
3) Modify the MySQl database credentials.
4) execute 

Thanks,
Pravu Mishra.