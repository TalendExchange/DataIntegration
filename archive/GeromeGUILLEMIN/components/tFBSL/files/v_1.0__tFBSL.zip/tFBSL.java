package routines;

import com.sun.jna.*;
/**
 * @(#)tFBSL.java
 *
 * tFBSL application
 *
 * @author Gerome GUILLEMIN
 * @version 1.00 2009/6/15
 */

public class tFBSL {

	// Most C libraries will just extend com.sun.jna.Library,
	abstract interface FBSL extends Library {

	    // Method declarations, constant and structure definitions go here
	    FBSL INSTANCE = (FBSL)Native.loadLibrary("FBSL", FBSL.class);

	    // Optional: wraps every call to the native library in a synchronized block, limiting native calls to one at a time
	    FBSL SYNC_INSTANCE = (FBSL)Native.synchronizedLibrary(INSTANCE);

		// FBSL.DLL prototypes declaration
	    int FBSL_ExecuteScriptBuffer( String szBuffer );
	    int FBSL_GetReturnValue(Object i, int j);
	}

	/**
	 * Execute some FBSL code (requires JNA.JAR + FBSL.DLL).
	 * {talendTypes} String
	 * {Category} StringHandling
	 * {param} string("Fbsl code").
	 * {example} tExecuteCode( "PI * 2 / 42" )
	 */
    public static String tExecuteCode( String sCodeBuffer ) {
        FBSL lib = FBSL.INSTANCE;
        int FBVT_STRING = 30, ret = 0;
        String st = "";
        byte[] s;

        // System.out.println( "__FBSL__ == " + sCodeBuffer );
        // Execution de la 1ere partie du code
        // System.out.println( "1/2 -----------------------------------------" );

        ret = lib.FBSL_ExecuteScriptBuffer( sCodeBuffer );
        if (ret == 0) {
        	if ( lib.FBSL_GetReturnValue( null, 0) !=0 ) {
        		int k = lib.FBSL_GetReturnValue( null, FBVT_STRING);
        		if (k > 0) {
	        		s = new byte[k];
	        		k = lib.FBSL_GetReturnValue( s, FBVT_STRING);
	        		st = new String(s);
        		}
        	}
        }
		return st;
    }

}
