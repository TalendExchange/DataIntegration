// template routine Java
package routines;

public class ValidateSecurities {

	private static String sedolErrorMessage;
	private static String isinErrorMessage;
	private static String cusipErrorMessage;

    /**
     * return A boolean indicating if the isin check digit is valid
     * 
     * 
     * {talendTypes} Boolean
     * 
     * {Category} ValidateSecurities
     * 
     * {param} string("") input: The string with isin to check for validity
     * 
     * {example} validateIsin("US0378331005")  
     */
	
	
    public static boolean validateIsin (String Isin) {  		

    		boolean isValid = false;
            int errorCode = 0;
    		int checkDigit=-1;

    		String trimIsin = Isin.trim().toUpperCase(); 

    		if (trimIsin.length() != 12 ) {
    		    errorCode = 1;
    		    isinErrorMessage = "Error: Isin " + trimIsin + " has a length of " + trimIsin.length() + "should be 12";
    		} else  {
    		    try {
    		        checkDigit = Integer.parseInt(trimIsin.substring(11));
    		    } catch (NumberFormatException e) {
    		        //The check digit isn't a number
    		        errorCode = 2;
    		        isinErrorMessage = "Error: Isin " + trimIsin + " has a non digit check value of " + checkDigit;
    		    }
    		}

    		int sumValues=0;

    		String allIsinValues="";
    		
    		ValidateSecurities.SecuritiesStringHelper stringHelper = new ValidateSecurities.SecuritiesStringHelper();
    		
    		if (errorCode == 0) {
    			try{
    				allIsinValues=stringHelper.convertToNumericString(trimIsin,false);
    			}catch (NumberFormatException e) {
    				errorCode = 3;
    				isinErrorMessage = "Error: Isin " + trimIsin + " contains invalid characters - should be 0-9..A-Z";
    			}
    		}

    		int total;
    		int calcCheck=-1;

    		if (errorCode == 0) {
    			//Split to odds and evens

    			stringHelper.splitToOddEvens(allIsinValues);
    			int[] odds = stringHelper.getOddsInt();
    			int[] evens = stringHelper.getEvensInt();
    			
    			String allOdds="";
    			String allEvens="";
    			int sumOdds=0;
    			int sumEvens=0;

    			if ((allIsinValues.length() -1) %2 == 0 ) {
    				//double odds
    				int[] doubleOdds = doubleValues(odds);
    				sumOdds = sumByConstituent(doubleOdds);
                    
    				// sum evens
    				sumEvens = sumByConstituent(evens);

    			} else {
    				//double evens
    				int[] doubleEvens = doubleValues(evens);
    				sumEvens = sumByConstituent(doubleEvens);
    				
    				//sum odds
    				sumOdds = sumByConstituent(odds);
    			}    			

    			total = sumOdds + sumEvens;
    			calcCheck = calcTensCompliment(total);
    		}

    		if (calcCheck != -1 && checkDigit != -1 && calcCheck == checkDigit) {
    			isValid = true;
    		} else {
    			if (errorCode == 0) {
    				errorCode = 4;
    				isinErrorMessage = "Error: Isin " + trimIsin + " has a check digit of " + checkDigit + 
    				" this should be " + calcCheck;
    			}
    		}
    		
    		return isValid;
    }

    
    /**
     * return A boolean indicating if the cusip check digit is valid
     * 
     * 
     * {talendTypes} Boolean
     * 
     * {Category} ValidateSecurities
     * 
     * {param} string("") input: The string containing the cusip to check for validity
     * 
     * {example} validateCusip("037833100")  
     */
    
    public static boolean validateCusip(String Cusip) {
    	
		boolean isValid = false;
        int errorCode = 0;
		int checkDigit=-1;

		String trimCusip = Cusip.trim().toUpperCase(); 

		if (trimCusip.length() != 9 ) {
		    errorCode = 1;
		    cusipErrorMessage = "Error : cusip " + trimCusip + " has a length of " + trimCusip.length() + " should be 9";
		} else  {
		    try {
		        checkDigit = Integer.parseInt(trimCusip.substring(8));
		    } catch (NumberFormatException e) {
		        //The check digit isn't a number
		        errorCode = 2;
		        cusipErrorMessage = "Error: cusip " + trimCusip + " has a non digit check value of " + checkDigit;
		    }
		}

		int total=0;
		
		ValidateSecurities.SecuritiesStringHelper stringHelper = new ValidateSecurities.SecuritiesStringHelper();
		
		if (errorCode == 0) {
			try{
				//Remove check digit and validate
				String c = trimCusip.substring(0, 7);
				stringHelper.splitToOddEvens(c);
				String[] odds = stringHelper.getOddsString();
				String[] evens = stringHelper.getEvensString();
				int [] oddsI = stringHelper.convertToNumericArray(odds, true);
				int [] evensI = stringHelper.convertToNumericArray(evens, true);
				evensI = doubleValues(evensI);
				int sumOdds = sumByConstituent(oddsI);
				int sumEvens = sumByConstituent(evensI);
				total = sumOdds + sumEvens;
			}catch (NumberFormatException e) {
				errorCode = 3;
				cusipErrorMessage = "Error: cusip " + trimCusip + " contains invalid characters - should be 0-9..A-Z or @#*";
			}
		}
    	
		int calcCheck = calcTensCompliment(total);
		
		if (errorCode == 0  && checkDigit != -1 && calcCheck == checkDigit) {
			isValid = true;
		} else {
			if (errorCode ==0) {
				errorCode = 4;
				cusipErrorMessage = "Error: cusip " + trimCusip + " has a check digit of " + checkDigit + 
				" this should be " + calcCheck;
			}
		}
		
		return isValid;
    	
    }

    
    /**
     * return A boolean indicating if the sedol check digit is valid
     * 
     * 
     * {talendTypes} Boolean
     * 
     * {Category} ValidateSecurities
     * 
     * {param} string("") input: The string containing the sedol to check for validity
     * 
     * {example} validateSedol("0263494")  
     */
    
    
    public static boolean validateSedol (String sedol) {
    	
		boolean isValid = false;
        int errorCode = 0;
		int checkDigit=-1;

		String trimSedol = sedol.trim().toUpperCase(); 

		if (trimSedol.length() != 7 ) {
		    errorCode = 1;
		    sedolErrorMessage = "Error : sedol " + trimSedol + " has a length of " + trimSedol.length() + " should be 7";
		} else  {
		    try {
		        checkDigit = Integer.parseInt(trimSedol.substring(6));
		    } catch (NumberFormatException e) {
		        //The check digit isn't a number
		        errorCode = 2;
		        sedolErrorMessage = "Error: sedol " + trimSedol + " has a non digit check value of " + checkDigit;
		    }
		}

		int total=0;
    	
		int[] weights = {1,3,1,7,3,9};
		ValidateSecurities.SecuritiesStringHelper stringHelper = new ValidateSecurities.SecuritiesStringHelper();
		
		for (int i=0 ; i<weights.length ; i++) {
			String s = trimSedol.substring(i, i+1);
			int d=0;
			try {
				d = stringHelper.convertCharacterToDigits(s, false);
			} catch (NumberFormatException e) {
				errorCode = 3;
				sedolErrorMessage = "Error: sedol " + trimSedol + " contains invalid characters - should be 0-9..A-Z";
			}
			total += d * weights[i];
		}
		
		int calcCheck = calcTensCompliment(total);
		
		if (errorCode == 0 && checkDigit != -1 && calcCheck == checkDigit) {
			isValid = true;
		} else {
			if (errorCode ==0 ) {
				errorCode = 4;
				sedolErrorMessage = "Error: sedol " + trimSedol + " has a check digit of " + checkDigit + 
				" this should be " + calcCheck;
			}
		}
		
		return isValid;
    }
    
    
    private static int calcTensCompliment (int value) {
    	return (10 - (value % 10)) % 10;
    }

    private static int[] doubleValues (int[] values) {
    	
    	int[] total= new int[values.length];
    	
    	for (int i=0 ; i<values.length ; i++) {
    		total[i] = values[i] * 2;
    	}
    	
    	return total;
    }
    
    private static int sumByConstituent(int[] values) {
    	//Add up values by position eg 13 -> (1+3) = 4
    	int sum = 0;
    	
    	for (int val : values) {
    		if(val >= 10) {
    			Integer posVal = (Integer) val;
    			String s = posVal.toString();
    			for (int i=0 ; i<s.length(); i++) {
    				sum += Integer.parseInt(s.substring(i, i+1));
    			}
    		} else {
    			sum += val;
    		}
    	}
    	
    	return sum;
    }
    
    
    /**
     * return A string containing the error Message for the isin validation routine. This method should be called
     * if the validateIsin routine returns false.
     *  
     * {talendTypes} String
     * 
     * {Category} ValidateSecurities
     * 
     * {example} getIsinErrorMessage()  
     */
    
    public static String getIsinErrorMessage() {
    	return isinErrorMessage;
    }
    
    /**
     * return A string containing the error Message for the sedol validation routine. This method should be called
     * if the validateSedol routine returns false.
     *  
     * {talendTypes} String
     * 
     * {Category} ValidateSecurities
     * 
     * {example} getSedolErrorMessage()  
     */
    
    public static String getSedolErrorMessage() {
    	return sedolErrorMessage;
    }
    
    /**
     * return A string containing the error Message for the cusip validation routine. This method should be called
     * if the validateCusip routine returns false.
     *  
     * {talendTypes} String
     * 
     * {Category} ValidateSecurities
     * 
     * {example} getCusipErrorMessage()  
     */
    
    public static String getCusipErrorMessage() {
    	return cusipErrorMessage;
    }
    
    private static class SecuritiesStringHelper {
    	//Want to split the string into two arrays of odds and evens
 
    	String[] odds;
    	String[] evens;
    	
    	public void StringHelper() {
    	}
    	
    	public void splitToOddEvens(String s) {
    		int l = s.length();
    		odds = new String[(l/2)+1];
    		evens = new String[(l/2)+1];
    		
			for (int i=0 ; i<l ; i++) {
				String c = s.substring(i, i+1);
				if(i%2 == 0) {
					odds[i/2] = c;
				} else {
					evens[i/2] = c;
				}
			}  
    	}
    	
    	public int[] convertToNumericArray (String[] ar, Boolean isCusip) throws NumberFormatException{
    		int[] vals = new int[ar.length];
    		
    		for (int i=0 ; i<ar.length ; i++) {
    			String s = ar[i];
    			if (s != null) {
    				try {
    					vals[i] = convertCharacterToDigits(s, isCusip);
    				} catch (NumberFormatException e) {
    					throw e;
    				}
    			}
    		}
    		
    		return vals;
    	}
    	
        private String convertToNumericString (String security, Boolean isCusip) throws NumberFormatException {
    		
        	String allValues="";
        	
        	for(int i=0; i<security.length() - 1; i++) {
    			String s = security.substring(i, i+1);
    			int value;
    			try {
    				value = convertCharacterToDigits(s, isCusip);
    			} catch (NumberFormatException e) {
    				throw e;
    			}
    			allValues += value ;
    		}
        	
        	return allValues;
        }
    	
    	
        private int convertCharacterToDigits (String s, Boolean isCusip) throws NumberFormatException {
	    	
        	int value;
        	
        	try {
				value = Integer.parseInt(s);
			} catch (NumberFormatException e) {
				//ok this isn't a number - see what the ascii value is
				int asciiValue = (int) s.charAt(0);
				//Characters A-Z lie in the range 65-90
				if (asciiValue >= 65 && asciiValue <=90) {
					value = asciiValue - 55;
				} else if (isCusip && s.compareTo("*")==0) {
					value = 36;
				} else if (isCusip && s.compareTo("@")==0) {
					value = 37;
				} else if (isCusip && s.compareTo("#")==0) {
					value = 38;
				}
				else {
					throw e;
				}
			}
			
			return value;
        }
        
        public int[] getOddsInt() throws NumberFormatException {
        	int[] o = new int[odds.length];
        	
        	for (int i=0 ; i<o.length ; i++) {
        		String s = odds[i];
        		if (s != null) {
	        		try {
	        			o[i] = Integer.parseInt(s);
	        		} catch (NumberFormatException e) {
	        			throw e;
	        		}
        		}
        	}
        	
        	return o;
        }
        
        public int[] getEvensInt() throws NumberFormatException {
        	int[] ev = new int[evens.length];
        	
        	for (int i=0 ; i<ev.length ; i++) {
        		String s = evens[i];
        		if (s != null) { 
	        		try {
	        			ev[i] = Integer.parseInt(s);
	        		} catch (NumberFormatException e) {
	        			throw e;
	        		}
        		}
        	}
        	
        	return ev;
        }
        
    	public String[] getOddsString() {
    		return odds;
    	}
    	
    	public String[] getEvensString() {
    		return evens;
    	}
    	
    }
    
}

